export let customerData: any = {
    't_list': [],
    't_string_1': '',
    't_obj_str': {},
    't_base_num': 1,
    'jishu': 0
};
export let factoryData: any = {
    't_list': [],
    't_string_1': '',
    't_obj_str': {},
    't_base_num': 1,
    'jishu': 0
};
export let produceData: any = {
    't_list': [],
    't_string_1': '',
    't_obj_str': {},
    't_base_num': 1,
    'jishu': 0
};
