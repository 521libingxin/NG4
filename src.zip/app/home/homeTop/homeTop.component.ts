
import { Component, OnInit } from '@angular/core';
@Component({
  moduleId: module.id,
  selector: 'app-hometop',
  templateUrl: './homeTop.component.html',
  styleUrls: ['./homeTop.component.css']
})
export class HomeTopComponent implements OnInit {
  constructor() { }
  ngOnInit() {
    // delete this.abc['lbx'];
    // console.log(this.abc);
  }
}
